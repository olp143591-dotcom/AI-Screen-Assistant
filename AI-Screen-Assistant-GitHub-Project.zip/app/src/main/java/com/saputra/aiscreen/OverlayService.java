package com.saputra.aiscreen;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import okhttp3.*;
import org.json.*;
import java.io.*;
import java.nio.ByteBuffer;

public class OverlayService extends Service {
    WindowManager wm; View bubble; MediaProjection projection; ImageReader reader; VirtualDisplay display;
    int density; Handler handler=new Handler(Looper.getMainLooper()); boolean busy=false;
    public void onCreate() { super.onCreate(); startForeground(42, notification()); showBubble(); }
    Notification notification() {
        if(Build.VERSION.SDK_INT>=26) ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("scan","AI Screen Assistant",NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this, Build.VERSION.SDK_INT>=26?"scan":"").setContentTitle("AI Screen Assistant aktif").setContentText("Ketuk tombol melayang untuk scan layar").setSmallIcon(android.R.drawable.ic_menu_search).build();
    }
    void showBubble() {
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        TextView b=new TextView(this); b.setText("AI"); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setGravity(Gravity.CENTER); b.setBackgroundColor(Color.rgb(65,95,210)); b.setElevation(12);
        bubble=b; int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(140,140,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;
        b.setOnTouchListener(new View.OnTouchListener(){float x,y; public boolean onTouch(View v, android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-x)<12&&Math.abs(e.getRawY()-y)<12) requestCapture();return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){p.x+=(int)(x-e.getRawX());p.y+=(int)(e.getRawY()-y);x=e.getRawX();y=e.getRawY();wm.updateViewLayout(bubble,p);return true;} return true;
        }});
        wm.addView(b,p);
    }
    void requestCapture() {
        Intent i=new Intent(this,MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP); i.putExtra("request_capture",true); startActivity(i);
        Toast.makeText(this,"Buka aplikasi lalu mulai scan melalui tombol di aplikasi. Izin tangkapan layar diperlukan.",Toast.LENGTH_LONG).show();
    }
    public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    public IBinder onBind(Intent i){return null;}
    public void onDestroy(){if(bubble!=null)wm.removeView(bubble); if(display!=null)display.release(); if(projection!=null)projection.stop(); super.onDestroy();}
}

package com.saputra.aiscreen;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    EditText endpoint, apiKey, model;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(28,32,28,24); root.setBackgroundColor(Color.rgb(18,24,42));
        TextView title = new TextView(this); title.setText("AI Screen Assistant"); title.setTextSize(26); title.setTextColor(Color.WHITE);
        TextView intro = new TextView(this); intro.setText("Scan layar dengan tombol melayang, baca teks soal, lalu minta penjelasan AI."); intro.setTextColor(Color.LTGRAY); intro.setPadding(0,16,0,18);
        endpoint = field("API endpoint (OpenAI-compatible)", "https://api.openai.com/v1/chat/completions");
        apiKey = field("API key (disimpan lokal di HP)", "");
        apiKey.setInputType(129);
        model = field("Nama model", "gpt-4o-mini");
        Button save = new Button(this); save.setText("Simpan pengaturan AI"); save.setOnClickListener(v -> {
            getSharedPreferences("settings",0).edit().putString("endpoint",endpoint.getText().toString().trim()).putString("key",apiKey.getText().toString().trim()).putString("model",model.getText().toString().trim()).apply();
            Toast.makeText(this,"Pengaturan disimpan di perangkat",Toast.LENGTH_SHORT).show();
        });
        Button overlay = new Button(this); overlay.setText("Aktifkan tombol melayang");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
            } else { startService(new Intent(this,OverlayService.class)); Toast.makeText(this,"Tombol AI aktif. Ketuk untuk scan.",Toast.LENGTH_LONG).show(); }
        });
        Button help = new Button(this); help.setText("Cara menggunakan");
        help.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Cara scan").setMessage("1. Simpan endpoint, API key, dan model yang kompatibel.\n2. Aktifkan tombol melayang.\n3. Buka aplikasi berisi soal.\n4. Ketuk tombol AI dan setujui perekaman layar Android.\n5. Teks hasil OCR dikirim ke API untuk dijawab.").setPositiveButton("OK",null).show());
        root.addView(title); root.addView(intro); root.addView(endpoint); root.addView(apiKey); root.addView(model); root.addView(save); root.addView(overlay); root.addView(help); setContentView(root);
        android.content.SharedPreferences p=getSharedPreferences("settings",0);
        endpoint.setText(p.getString("endpoint","https://api.openai.com/v1/chat/completions")); apiKey.setText(p.getString("key","")); model.setText(p.getString("model","gpt-4o-mini"));
    }
    EditText field(String hint,String val) { EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setText(val); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY); return e; }
}
